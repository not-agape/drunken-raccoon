% AV3 - Algoritmos (S15)
% Nome: Pedro Henrique Matias
% RA: 2361914 - Data: 25/08/2021

## Quest�o 4: Fun��o Calcula M�dia

function media_a = calculaMediaA(n1, n2, n3)

  media_a = (n1+n2+n3) / 3; 
  
endfunction