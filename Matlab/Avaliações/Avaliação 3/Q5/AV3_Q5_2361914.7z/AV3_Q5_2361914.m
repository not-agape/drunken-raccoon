% AV3 - Algoritmos (S15)
% Nome: Pedro Henrique Matias
% RA: 2361914 - Data: 25/08/2021

## Quest�o 5: Implementa��o da Fun��o �C -> K �F

## entrada/sa�da/processamento -> Implementa��o da Fun��o
[tempK, tempF] = c2k(input("Digite uma Temperatura em �C: "));
printf("A temperatura informada corresponde a %f K ou %.2f�F.\n", tempK, tempF);